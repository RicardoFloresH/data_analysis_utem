---
annotations_creators:
- found
language: []
language_creators: []
license:
- apache-2.0
multilinguality: []
pretty_name: 'Mini-Croupier: Magic the Gathering creatures mini-dataset'
size_categories:
- n<1K
source_datasets:
- original
tags:
- mgt
- magic-card-game
- creature-dataset
task_categories:
- image-classification
task_ids:
- binary-class-image-classification
---


## Dataset Description

TODO

### Dataset Summary

TODO

## Dataset Creatioon

TODO
